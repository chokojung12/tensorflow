import os
import platform


print("hello world")
print(platform.version())
