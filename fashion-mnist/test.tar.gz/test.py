import platform
from time import sleep

print(platform.platform())
print(platform.system())
print(platform.release())
print(platform.version())

sleep(360)


